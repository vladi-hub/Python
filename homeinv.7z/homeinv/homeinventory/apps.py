from django.apps import AppConfig


class HomeinventoryConfig(AppConfig):
    name = 'homeinventory'
